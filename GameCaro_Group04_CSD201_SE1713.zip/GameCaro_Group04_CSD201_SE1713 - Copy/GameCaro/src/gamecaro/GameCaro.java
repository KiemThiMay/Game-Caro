/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamecaro;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * @author Hoang Huy Phuong - CE170428
 */
public class GameCaro extends javax.swing.JFrame {

	public static final int numRows = 10;
	public static final int numCols = 10;

	public static final int redChess = 0;
	public static final int blueChess = 1;
	public static final int turnOnValue = 10;
	public static int countRed = 0;
	public static int countBlue = 0;
	private Timer timer;
	private TimePanel timePanel;
	private int secondCount = 0;
	Card map[][];
	int luotDi; //luot di = 0 => quan Do, luot di = 1 => quan Xanh

	public void generateBoard() {
		map = new Card[numRows][numCols];
		pnlBoard.setLayout(new GridLayout(numRows, numCols));
		pnlBoard.removeAll();
		pnlBoard.revalidate();
		pnlBoard.repaint();
		int mau = 1;
		for (int i = 0; i < numRows; i++) {
			for (int j = 0; j < numCols; j++) {
				if ((i + j) % 2 == 0) {
					mau = 1;
				} else {
					mau = 2;
				}
				map[i][j] = new Card(this, i, j, mau);
				pnlBoard.add(map[i][j]);
			}
		}
		luotDi = blueChess;
	}

	public int getLuotDi() {
		return luotDi;
	}

	public void luotDiTiepTheo() {
		if (luotDi == redChess) {
			luotDi = blueChess;
		} else {
			luotDi = redChess;
		}
	}

	public boolean coQuanCo(Card c) {
		return c.getValue() > 9;
	}

	public boolean khacMau(Card c, int luotDi) {
		return (c.getValue() % GameCaro.turnOnValue) != luotDi;
	}

	public boolean cungMau(Card c, int luotDi) {
		return (c.getValue() % GameCaro.turnOnValue) == luotDi;
	}

	public boolean win(int x, int y) {
		int k, j;
		int d = 0;
		// kt chieu doc
		for (k = -4; k <= 4; k++) {
			if (x + k >= 0 && x + k < numRows) {
				if (coQuanCo(map[x + k][y]) && khacMau(map[x + k][y], luotDi)) {
					d++;
				} else if (d < 5) {
					d = 0;
				}
			}
		}
		if (d >= 5) {
			return true;
		} else {
			d = 0;
		}
		//xet ngang
		for (k = -5; k <= 5; k++) {
			if (y + k >= 0 && y + k < numRows) {
				if (coQuanCo(map[x][y + k]) && khacMau(map[x][y + k], luotDi)) {
					d++;
				} else if (d < 5) {
					d = 0;
				}
			}
		}
		if (d >= 5) {
			return true;
		} else {
			d = 0;
		}
		//cheo
		for (k = -4, j = 4; k <= 4 && j >= -4; k++, j--) {
			if (y + k >= 0 && y + k < numRows && x + j >= 0 && x + j < numCols) {
				if (coQuanCo(map[x + j][y + k]) && khacMau(map[x + j][y + k], luotDi)) {
					d++;
				} else if (d < 5) {
					d = 0;
				}
			}
		}
		if (d >= 5) {
			return true;
		} else {
			d = 0;
		}
		for (k = -4; k <= 4; k++) {
			if (y + k >= 0 && y + k < numRows && x + k >= 0 && x + k < numCols) {
				if (coQuanCo(map[x + k][y + k]) && khacMau(map[x + k][y + k], luotDi)) {
					d++;
				} else if (d < 5) {
					d = 0;
				}
			}
		}
		if (d >= 5) {
			return true;
		}
		return false;
	}

	public void updatePoint(int checkPoint) {
		if (checkPoint == 1) {
			countRed++;
		} else if (checkPoint == 0) {
			countBlue++;
		}
		lblRed.setText(countRed + "");
		lblBlue.setText(countBlue + "");
	}

	void startClock() {
		timer = new Timer(1000, e -> {
			secondCount++;
			timePanel.repaint();
		});
		timer.start();
	}

	public void stopClock() {
		if (timer != null) {
			timer.stop();
		}
	}
	private void addTimePanelToTime() {
        timePanel = new TimePanel();
        pnlTimer.setLayout(new BorderLayout()); // Sử dụng BorderLayout cho time panel
        pnlTimer.add(timePanel, BorderLayout.CENTER); // Thêm timePanel vào trung tâm của time panel
    }


	public void reset() {
		generateBoard();
		secondCount = -1;
		countRed = -1;
		countBlue = -1;
		updatePoint(1);
		updatePoint(0);
		startClock();
	}

	private class TimePanel extends JPanel {

		private static final int PANEL_WIDTH = 150; // Độ rộng của TimePanel
		private static final int PANEL_HEIGHT = 40; // Độ cao của TimePanel

		@Override
		public Dimension getPreferredSize() {
			return new Dimension(PANEL_WIDTH, PANEL_HEIGHT); // Xác định kích thước ban đầu cho TimePanel
		}

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.setFont(new Font("Arial", Font.PLAIN, 18));
			g.setColor(Color.RED);

			int minutes = secondCount / 60;
			int seconds = secondCount % 60;
			String timeString = String.format("%02d:%02d", minutes, seconds);
			g.drawString(timeString, 10, getHeight() - 10);
		}

		// bắt đầu chương trình là đếm luôn 
		public TimePanel() {
			// Thêm sự kiện componentShown cho TimePanel
			this.addComponentListener(new java.awt.event.ComponentAdapter() {
				public void componentShown(java.awt.event.ComponentEvent evt) {
					startClock();
				}
			});
		}
	}

	/**
	 * Creates new form GameReversi
	 */
	public GameCaro() {
		initComponents();
		addTimePanelToTime();
		this.setLocationRelativeTo(null);
		generateBoard();
	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlGameInfo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblRed = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblBlue = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        pnlTimer = new javax.swing.JPanel();
        pnlBoard = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Game Caro");

        pnlGameInfo.setBorder(javax.swing.BorderFactory.createTitledBorder("Game Information"));
        pnlGameInfo.setForeground(new java.awt.Color(51, 102, 255));

        jLabel1.setForeground(new java.awt.Color(255, 51, 51));
        jLabel1.setText("Red Player");

        lblRed.setForeground(new java.awt.Color(255, 51, 51));
        lblRed.setText("0");

        jLabel2.setForeground(new java.awt.Color(51, 102, 255));
        jLabel2.setText("Blue Player");

        lblBlue.setForeground(new java.awt.Color(51, 102, 255));
        lblBlue.setText("0");

        jButton1.setText("Reset");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel3.setText("Time");

        javax.swing.GroupLayout pnlTimerLayout = new javax.swing.GroupLayout(pnlTimer);
        pnlTimer.setLayout(pnlTimerLayout);
        pnlTimerLayout.setHorizontalGroup(
            pnlTimerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        pnlTimerLayout.setVerticalGroup(
            pnlTimerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 53, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout pnlGameInfoLayout = new javax.swing.GroupLayout(pnlGameInfo);
        pnlGameInfo.setLayout(pnlGameInfoLayout);
        pnlGameInfoLayout.setHorizontalGroup(
            pnlGameInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlGameInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblRed)
                .addGap(44, 44, 44)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblBlue)
                .addGap(71, 71, 71)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addGap(41, 41, 41)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlTimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlGameInfoLayout.setVerticalGroup(
            pnlGameInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlGameInfoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlGameInfoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lblRed)
                    .addComponent(jLabel2)
                    .addComponent(lblBlue)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jLabel3))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pnlGameInfoLayout.createSequentialGroup()
                .addComponent(pnlTimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 32, Short.MAX_VALUE))
        );

        pnlBoard.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pnlBoard.setPreferredSize(new java.awt.Dimension(640, 640));
        pnlBoard.setLayout(new java.awt.GridLayout(1, 0));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnlGameInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pnlBoard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnlGameInfo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pnlBoard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
		GameCaro g = new GameCaro();

        // Start the clock for the new instance of GameReversi
        g.startClock();
		g.setVisible(true);
		dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
		Menu m = new Menu();
        m.show();

        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		//<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
		/* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(GameCaro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(GameCaro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(GameCaro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(GameCaro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		//</editor-fold>
		//</editor-fold>
		
		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			Menu menu = new Menu();
			public void run() {
				menu.setVisible(true);
			}
		});
	}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel lblBlue;
    private javax.swing.JLabel lblRed;
    private javax.swing.JPanel pnlBoard;
    private javax.swing.JPanel pnlGameInfo;
    private javax.swing.JPanel pnlTimer;
    // End of variables declaration//GEN-END:variables
}
