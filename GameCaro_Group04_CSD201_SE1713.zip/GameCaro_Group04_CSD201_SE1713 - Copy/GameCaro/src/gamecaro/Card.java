/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gamecaro;

import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Hoang Huy Phuong - CE170428
 */
public class Card extends JLabel {

	int row, col, value;
	private MouseListener mouseClicked;
	private GameCaro parent;

	public Card(GameCaro parent, int row, int col, int value) {
		this.parent = parent;
		this.row = row;
		this.col = col;
		this.value = value;
		this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
//		this.setBorder(BorderFactory.createRaisedBevelBorder());
//		showBall();
		this.mouseClicked = new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				cardClicked();
			}
		};
		this.addMouseListener(mouseClicked);
		updateFace();
	}
	
	public void cardClicked() {
		turnOn(parent.getLuotDi());
		parent.luotDiTiepTheo();
		this.removeMouseListener(mouseClicked);
		this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		
		if (parent.win(row, col) && (this.value % GameCaro.turnOnValue) == 1) {
			parent.stopClock();
			JOptionPane.showMessageDialog(null, "X win!", "Game Over!", JOptionPane.INFORMATION_MESSAGE);
			if(JOptionPane.showConfirmDialog(null, "Do you want play continues?", "Warning", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
				parent.generateBoard();
				parent.updatePoint(0);
				parent.startClock();
			}else{
				parent.reset();
			};
			
		}else if(parent.win(row, col) && (this.value % GameCaro.turnOnValue) == 0){
			parent.stopClock();
			JOptionPane.showMessageDialog(null, "O win!", "Game Over!", JOptionPane.INFORMATION_MESSAGE);
			if(JOptionPane.showConfirmDialog(null, "Do you want play continues?", "Warning", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION){
				parent.generateBoard();
				parent.updatePoint(1);
				parent.startClock();
			}else{
				parent.reset();
			};
		}
	}

	public void updateFace() {
		this.setIcon(getFace());
	}

	public ImageIcon getFace() {
		return new ImageIcon(getClass().getResource("/img/" + value + ".png"));
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getCol() {
		return col;
	}

	public void setCol(int col) {
		this.col = col;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
		updateFace();
	}

	public void turnOn(int luotDi) {
		this.value = value * GameCaro.turnOnValue + luotDi;
		updateFace();
	}
	public void reTurn() {
		int bg = this.value / GameCaro.turnOnValue;
		int v1 = this.value % GameCaro.turnOnValue;
		v1 = 1 - v1;
		this.value = bg * GameCaro.turnOnValue + v1;
		updateFace();
	}
}
